<?php

try {
    require_once 'm2mp.class.php';
    $m2mp = new m2mp ( "127.0.0.1", 27015 );
    $data = $m2mp->pulse();
    var_dump($data);
}
catch ( Exception $e ) {
    die ( 'Failed to get server information!' );
}

?>