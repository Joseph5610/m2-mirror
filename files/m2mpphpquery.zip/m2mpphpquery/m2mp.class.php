<?php

class m2mp {
    
    private $socket, $data;
    
    function __construct ( $ip, $port = 27015, $timeout = 3 ) {
        if ( !$this->socket = @fsockopen ( "udp://{$ip}", ($port + 1), $errno, $errstr, $timeout ) ) {
            throw new Exception ( "Unable to connect to {$ip}:{$port}!" );
        }
        
        @socket_set_timeout ( $this->socket, $timeout );
        $this->data['ip'] = $ip;
        $this->data['port'] = $port;
    }
    
    function __destruct () {
        @fclose ( $this->socket );
        unset ( $this->data );
    }
    
    private function unpack ( $data ) {
        $binary = unpack ( "C*", $data );
        
        $hostnamelen = $binary[5];
        $this->data['hostname'] = substr ( $data, 5, ($hostnamelen - 1) );

        $playerslen = $binary[5 + $hostnamelen];
        $this->data['playercount'] = (int)substr ( $data, (5 + $hostnamelen), ($playerslen - 1) );
        
        $maxplayerslen = $binary[5 + $hostnamelen + $playerslen];
        $this->data['maxplayers'] = (int)substr ( $data, (5 + $hostnamelen + $playerslen), ($maxplayerslen - 1) );
        
        $gamemodelen = $binary[5 + $hostnamelen + $playerslen + $maxplayerslen];
        $this->data['gamemode'] = substr ( $data, (5 + $hostnamelen + $playerslen + $maxplayerslen), ($gamemodelen - 1) );
    
        $this->data['password'] = (bool)$binary[5 + $hostnamelen + $playerslen + $maxplayerslen + $gamemodelen];
        
        if ( $this->data['playercount'] > 0 ) {
            $this->data['players'] = array ();
            $offset = 5 + $hostnamelen + $playerslen + $maxplayerslen + $gamemodelen + 1;
            
            for ( $i = 0; $i < $this->data['playercount']; $i++ ) {
                $playernamelen = ($binary[$offset] - 1);
                array_push ( $this->data['players'], substr ( $data, $offset, $playernamelen ) );
                $offset += ($playernamelen + 1);
            }
        }
        
        return $this->data;
    }
    
    public function pulse () {
        if ( !$this->socket ) {
            throw new Exception ( "Socket not open!" );
        }
        
        $this->data['ping'] = microtime ( true );
        
        if ( !@fwrite ( $this->socket, "M2MPi" ) ) {
            throw new Exception ( "Failed to write data to the socket!" );
        }
        
        if ( !$result = @fread ( $this->socket, 1024 ) ) {
            throw new Exception ( "Failed to read data from the socket!" );
        }
        
        $this->data['ping'] = (int)round ((microtime(true) - $this->data['ping']) * 1000, 0);
        
        if ( $result[0] != 'M' || $result[1] != '2' || $result[2] != 'M' || $result[3] != 'P' ) {
            throw new Exception ( "Corrupt packet data received from server!" );
        }
        
        return $this->unpack ( $result );
    }
    
}

?>